package edu.curtin.saed.assignment1;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Handling the Airports in the simulation and it's data
 * REFERENCES: 
 */

import java.util.concurrent.ConcurrentLinkedQueue;

public class Airport 
{
    private int id;
    private double x;
    private double y;

    /*Using a concurrent queu instead of an interface implementation mainly allows me to run the application smoothly and gives me less
    erros while handling the threads. Besides I don't need multiple implementations for this scenario anyways*/
    @SuppressWarnings("PMD.LooseCoupling")
    private ConcurrentLinkedQueue<Plane> availablePlanes;
    private GridAreaIcon icon;
    
    

    //The Constructor
    public Airport(int id, double  x, double y, GridArea mapArea) 
    {
        this.id = id;
        this.x = x;
        this.y = y;
        this.availablePlanes = new ConcurrentLinkedQueue<>();
        this.icon = new GridAreaIcon(x, y, 0, 1.0,
            getClass().getClassLoader().getResourceAsStream("airport.png"),
            "\nAirport " + id);

            //
            //THIS NEEDS SOME BEATING
            //
        mapArea.getIcons().add(this.icon);
        updateIconPosition();
    }
    
    public int getId() { return id; }
    public double getX() { return x; }
    public double getY() { return y; }
    
    //PURPOSE:- Add a plane to the airport
    public void addPlane(Plane plane) 
    {
        availablePlanes.offer(plane);

        
    }
    
    //PURPOSE:- Get a plane from the airport
    public Plane getAvailablePlane() 
    {
        return availablePlanes.poll();
    }
    
    //PURPOSE:- return a plane to the airport
    public void returnPlane(Plane plane) 
    {
        availablePlanes.offer(plane);
    }

    //PURPOSE:- Update the position of the icon
    private void updateIconPosition() 
    {

        
        icon.setPosition(x, y);


    }

    
}
