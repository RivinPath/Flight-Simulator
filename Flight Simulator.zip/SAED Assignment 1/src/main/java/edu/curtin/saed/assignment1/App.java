package edu.curtin.saed.assignment1;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Main Simulation controlling class (Starting, ending, setting up the GUI)
 * REFERENCES: 
 */

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * This is demonstration code intended for you to modify. Currently, it sets up a rudimentary
 * JavaFX GUI with the basic elements required for the assignment.
 *
 * (There is an equivalent Swing version of this, which you can use if you have trouble getting
 * JavaFX as a whole to work.)
 *
 * You will need to use the GridArea object, and create various GridAreaIcon objects, to represent
 * the on-screen map.
 *
 * Use the startBtn, endBtn, statusText and textArea objects for the other input/output required by
 * the assignment specification.
 *
 * Break this up into multiple methods and/or classes if it seems appropriate. Promote some of the
 * local variables to fields if needed.
 */



public class App extends Application 
{
    private GridArea mapArea;
    private Button startButton;
    private Button endButton;

    //in Update make this static
    //private Label statusLabel;

    private TextArea logArea;
    private AirTrafficSimulationLogic simulationLogic;

    private static final int MAP_WIDTH = 10;
    private static final int MAP_HEIGHT = 10;

    //Update
    private static Label statusLabel;

    //PURPOSE:- Start the GUI
    @Override
    public void start(Stage stage) 
    {
        initializeComponents();
        setupLayout(stage);
        setupEventHandlers(stage);
        
    }

    //PURPOSE:- Initialize the GUI components
    private void initializeComponents() 
    {
        mapArea = new GridArea(MAP_WIDTH, MAP_HEIGHT);
        mapArea.setStyle("-fx-background-color: #006000;");
        startButton = new Button("Start");
        endButton = new Button("End");
        statusLabel = new Label("Simulation not started");
        logArea = new TextArea();

        //simulationLogic = new AirTrafficSimulationLogic(mapArea, logArea);

        
        simulationLogic = new AirTrafficSimulationLogic(mapArea, logArea, statusLabel);
    }

    //PURPOSE:- Set the layout of the GUI
    private void setupLayout(Stage stage) 
    {
        var toolbar = new ToolBar();
        toolbar.getItems().addAll(startButton, endButton, new Separator(), statusLabel);

        var splitPane = new SplitPane();
        splitPane.getItems().addAll(mapArea, logArea);

        //This was 0.75
        splitPane.setDividerPositions(0.74);

        stage.setTitle("Air Traffic Simulator");
        var contentPane = new BorderPane();
        contentPane.setTop(toolbar);
        contentPane.setCenter(splitPane);

        var scene = new Scene(contentPane, 1200, 1000);
        stage.setScene(scene);
        stage.show();
    }

    //PURPOSE:- Initialize the start and end button
    private void setupEventHandlers(Stage stage) 
    {
        startButton.setOnAction(e -> startSimulation());
        endButton.setOnAction(e -> endSimulation());

        stage.setOnCloseRequest((event) -> 
        {
            simulationLogic.endSimulation();
        });
    }

    //PURPOSE:- Start the simulation with correct component setting
    private void startSimulation() 
    {
        startButton.setDisable(true);
        endButton.setDisable(false);
        statusLabel.setText("Simulation running");
        simulationLogic.startSimulation();
    }

    //PURPOSE:- End the simulation with the correct component setting
    private void endSimulation() 
    {
        startButton.setDisable(false);
        endButton.setDisable(true);
        statusLabel.setText("Simulation ended");
        simulationLogic.endSimulation();
    }


    

    @Override
    public void stop() 
    {
        simulationLogic.endSimulation();
    }

    public static void main(String[] args) 
    {
        launch();
    }

    //Update
    public static void setStatusText(String text) 
    {
        if (statusLabel != null) 
        {
            Platform.runLater(() -> statusLabel.setText(text));
        }
    }
}