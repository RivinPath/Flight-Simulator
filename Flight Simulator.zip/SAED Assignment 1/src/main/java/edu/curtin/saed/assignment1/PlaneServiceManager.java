package edu.curtin.saed.assignment1;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Implementing the Plane service feature
 * REFERENCES: 
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;

public class PlaneServiceManager 
{
    private ExecutorService threadPool;

    //Update
    private SimulationController simulationController;
    
    //The Constructor
    public PlaneServiceManager(ExecutorService threadPool) 
    {
        this.threadPool = threadPool;
    }

    

    //PURPOSE:- Service a plane
    public void servicePlane(Plane plane, Airport airport) 
    {
        threadPool.submit(() -> 
        {
            try 
            {
                plane.startService();
                simulationController.incrementPlanesInService();
                Process proc = Runtime.getRuntime().exec(
                    new String[]
                    {"saed_plane_service",
                        String.valueOf(airport.getId()),
                        String.valueOf(plane.getId())
                    });
                
                BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                String line;
                while ((line = br.readLine()) != null) 
                {
                    System.out.println("Plane service output: " + line);
                }
                
                proc.waitFor();
                plane.endService();
                simulationController.decrementPlanesInService();
            } 
            catch (IOException | InterruptedException e) 
            {
                System.err.println("Error in plane service: " + e.getMessage());
            }
        });
    }

    //PURPOSE:- Setting the simulation controller
    public void setSimulationController(SimulationController simulationController) 
    {
        this.simulationController = simulationController;
    }

    
}


