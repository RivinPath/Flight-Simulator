package edu.curtin.saed.assignment1;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Logic of the Simulation
 * REFERENCES: 
 */

import java.util.Map;
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class AirTrafficSimulationLogic 
{
    private GridArea mapArea;
    private TextArea logArea;
    
    private SimulationController simulationController;
    private Map<Integer, Airport> airports;
    private Map<Integer, Plane> planes;
    
    private ExecutorService threadPool;

    
    //private BlockingQueue<FlightRequest> flightRequestQueue;
    
    private static final int NUM_AIRPORTS = 10;
    private static final int PLANES_PER_AIRPORT = 10;

    //Thought the value of statusLabel field is not used it's needed for the constructor so I can set up the live in-flight, serving and completed flight status display function to work
    @SuppressWarnings("PMD.UnusedPrivateField")
    private Label statusLabel;
    //private PlaneServiceManager planeServiceManager;
    
    


    //The Constructor
    public AirTrafficSimulationLogic(GridArea mapArea, TextArea logArea, Label statusLabel) 
    {
        this.mapArea = mapArea;
        this.logArea = logArea;
        this.statusLabel = statusLabel;
        
        initializeComponents();
    }
    
    //PURPOSE:- Initialize the Simulation
    private void initializeComponents() 
    {
        threadPool = Executors.newCachedThreadPool();

        BlockingQueue<FlightRequest> flightRequestQueue = new LinkedBlockingQueue<>();
        //flightRequestQueue = new LinkedBlockingQueue<>();

        //Pmd warning shite
        PlaneServiceManager planeServiceManager;
        
        airports = new ConcurrentHashMap<>();
        planes = new ConcurrentHashMap<>();
        
        initializeAirportsAndPlanes();
        
        //simulationController = new SimulationController(threadPool, flightRequestQueue, airports, planes, mapArea, logArea);

        //Update
        simulationController = new SimulationController(threadPool, flightRequestQueue, airports, planes, mapArea, logArea);
        planeServiceManager = new PlaneServiceManager(threadPool);
        simulationController.setPlaneServiceManager(planeServiceManager);
        planeServiceManager.setSimulationController(simulationController);
    }
    
    

    //PURPOSE:- Initialize the airports and planes
    private void initializeAirportsAndPlanes() 
    {
        Random rand = new Random();
        for (int i = 0; i < NUM_AIRPORTS; i++) 
        {
            double x = rand.nextDouble() * (/*mapArea.getWidth()*/ 10- 1);
            double y = rand.nextDouble() * (/*mapArea.getHeight()*/ 10 - 1);
            //int xValue = 6;
            //Airport airport = new Airport(i, xValue, xValue, mapArea);

            //Airport airport = new Airport(i, 6, 7, mapArea);
            
            //int x = rand.nextInt((int)mapArea.getWidth()); // Use int for discrete grid positions
            //int y = rand.nextInt((int)mapArea.getHeight()); // Use int for discrete grid positions


            //Putting Airports on the map
            Airport airport = new Airport(i, x, y, mapArea);
            airports.put(i, airport);
            
            //Putting planes on the map
            for (int j = 0; j < PLANES_PER_AIRPORT; j++) 
            {
                int planeId = i * PLANES_PER_AIRPORT + j;
                Plane plane = new Plane(planeId, x, y, airport, mapArea);
                planes.put(planeId, plane);
                airport.addPlane(plane);
            }
        }
    }

    
    //PURPOSE:- Trigger the simulation
    public void startSimulation() 
    {
        simulationController.startSimulation();
    }
    
    //PURPOSE:- End the simulation and stop the thread pool
    public void endSimulation() 
    {
        simulationController.endSimulation();
        threadPool.shutdownNow();
    }

    
    
    
}

