package edu.curtin.saed.assignment1;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Handling the Flight Requests
 * REFERENCES: 
 */

public class FlightRequest 
{
    private int originAirportId;
    private int destinationAirportId;
    
    //The Constructor
    public FlightRequest(int originAirportId, int destinationAirportId) 
    {
        this.originAirportId = originAirportId;
        this.destinationAirportId = destinationAirportId;
    }
    
    //The Getters
    public int getOriginAirportId() { return originAirportId; }
    public int getDestinationAirportId() { return destinationAirportId; }
}
