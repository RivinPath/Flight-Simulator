package edu.curtin.saed.assignment1;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Handling the planes in the simulation
 * REFERENCES: 
 */

public class Plane 
{
    private int id;
    private double x;
    private double y;
    private Airport currentAirport;
    private Airport destinationAirport;
    private boolean inFlight;
    private boolean underService;
    private GridAreaIcon icon;
    private static final double SPEED = 1.0;
    
    

    //The Constructor
    public Plane(int id, double x, double y, Airport airport, GridArea mapArea) 
    {
        this.id = id;
        this.x = x;
        this.y = y;
        this.currentAirport = airport;
        this.inFlight = false;
        this.underService = false;
        this.icon = new GridAreaIcon(x, y, 0, 1.0,
            getClass().getClassLoader().getResourceAsStream("plane.png"),
            "Plane " + id);

            //
            //Adding Plan icons to the map
            //
        mapArea.getIcons().add(this.icon);
        updateIconPosition();
    }
    
    //Getters
    public int getId() { return id; }
    public boolean isInFlight() { return inFlight; }
    public boolean isUnderService() { return underService; }
    
    

    //PURPOSE:- Start the flight of a plane
    public void startFlight(Airport destination) 
    {
        this.destinationAirport = destination;
        this.inFlight = true;
        this.icon.setShown(true);
        updateIconPosition();
    }
    
    
//PURPOSE:- Update the position of the plane
    public void updatePosition() 
    {
        if (inFlight) 
        {
            double dx = destinationAirport.getX() - x;
            double dy = destinationAirport.getY() - y;
            double distance = Math.sqrt(dx*dx + dy*dy);
            
            if (distance <= SPEED) 
            {
                //Plane laneded
                x = destinationAirport.getX();
                y = destinationAirport.getY();
                land(destinationAirport);
            } 
            else 
            {
                //Fligth takeoff
                x += (dx / distance) * SPEED;
                y += (dy / distance) * SPEED;
            }
            
            
            updateIconPosition();

            //Original
            //double angle = Math.toDegrees(Math.atan2(dy, dx));

            //Update
            double angle = 90.0+(Math.toDegrees(Math.atan2(dy, dx)));


            icon.setRotation(angle);
            //updateIconPosition();

            //Platform.runLater(() -> mapArea.requestLayout());
        }
    }

    
    
    

    //PURPOSE:- Land the plane
    public void land(Airport airport) 
    {
        this.currentAirport = airport;
        this.inFlight = false;
        this.icon.setShown(false);
        updateIconPosition();
    }
    
    //PURPOSE:- Start the service of a plane
    public void startService() 
    {
        this.underService = true;
    }
    
    //PURPOSE:- End the service of a plane
    public void endService() 
    {
        this.underService = false;
        this.currentAirport.returnPlane(this);
    }

    //PURPOSE:- Update the position of the icon
    private void updateIconPosition() 
    {
        icon.setPosition(x, y);
    }

    

}


