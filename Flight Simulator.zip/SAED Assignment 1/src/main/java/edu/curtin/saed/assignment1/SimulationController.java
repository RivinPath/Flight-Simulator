package edu.curtin.saed.assignment1;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Implementing the threads and 
 * REFERENCES: 
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;

import javafx.application.Platform;
import javafx.scene.control.TextArea;

public class SimulationController 
{
    private ExecutorService threadPool;
    private BlockingQueue<FlightRequest> flightRequestQueue;
    private Map<Integer, Airport> airports;

    //Planes field is neccesary for making the constructor. This class handles all the simulations. Having the plane fields is neccesasry by design.
    @SuppressWarnings("PMD.UnusedPrivateField")
    private Map<Integer, Plane> planes;
    private GridArea mapArea;
    private TextArea logArea;
    private volatile boolean isRunning = false;
    private PlaneServiceManager planeServiceManager;

    //Update
    private int planesInFlight = 0;
    private int planesInService = 0;
    private int completedTrips = 0;
    
    //The Constructor
    public SimulationController(ExecutorService threadPool, BlockingQueue<FlightRequest> flightRequestQueue,
                                Map<Integer, Airport> airports, Map<Integer, Plane> planes,
                                GridArea mapArea, TextArea logArea) 
    {
        this.threadPool = threadPool;
        this.flightRequestQueue = flightRequestQueue;
        this.airports = airports;
        this.planes = planes;
        this.mapArea = mapArea;
        this.logArea = logArea;
        this.planeServiceManager = new PlaneServiceManager(threadPool);
    }
    
    //PURPOSE:- Starts the main simulation threads
    public void startSimulation() 
    {
        isRunning = true;
        for (Airport airport : airports.values()) 
        {
            startFlightRequestGenerator(airport.getId());
        }
        processPlaneMoves();
    }
    
    //PURPOSE:- End the simulation
    public void endSimulation() 
    {
        isRunning = false;
    }
    
    


    //PURPOSE:- Generate flight requests for each airport
    private void startFlightRequestGenerator(int airportId) 
    {
        threadPool.submit(() -> 
        {
            try 
            {
                Process proc = Runtime.getRuntime().exec(
                    new String[]{"saed_flight_requests",
                                 String.valueOf(airports.size()),
                                 String.valueOf(airportId)});
                
                BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                String line;
                while (isRunning && (line = br.readLine()) != null) 
                {
                    try 
                    {
                        int destinationAirport = Integer.parseInt(line);
                        flightRequestQueue.put(new FlightRequest(airportId, destinationAirport));
                    } 
                    catch (NumberFormatException e) 
                    {
                        logMessage("Flight request generator output: " + line);
                    }
                }
                if (!isRunning) 
                {
                    proc.destroy();
                }
            } 
            catch (IOException | InterruptedException e) 
            {
                if (isRunning) 
                {
                    logMessage("Error in flight request generator: " + e.getMessage());
                }
            }
        });
    }
    
    

    

    //PURPOSE:- Handling the movement of a plane on flight
    private void processPlaneMoves() 
    {
        threadPool.submit(() -> 
        {
            while (isRunning) 
            {
                try 
                {
                    FlightRequest request = flightRequestQueue.take();
                    Airport origin = airports.get(request.getOriginAirportId());
                    Airport destination = airports.get(request.getDestinationAirportId());
                    
                    Plane availablePlane = origin.getAvailablePlane();
                    if (availablePlane != null) 
                    {
                        availablePlane.startFlight(destination);
                        incrementPlanesInFlight();
                        logMessage("Plane " + availablePlane.getId() + " departing from Airport " + origin.getId() + " to Airport " + destination.getId());
                        
                        while (availablePlane.isInFlight()) 
                        {

                            //This is the speed (Should be 100)
                            Thread.sleep(100); 
                            availablePlane.updatePosition();
                            Platform.runLater(() -> mapArea.requestLayout());
                        }
                        
                        decrementPlanesInFlight();
                        incrementCompletedTrips();
                        logMessage("Plane " + availablePlane.getId() + " landed at Airport " + destination.getId());
                        planeServiceManager.servicePlane(availablePlane, destination);
                    }
                } 
                catch (InterruptedException e) 
                {
                    if (isRunning) 
                    {
                        logMessage("Error processing plane moves: " + e.getMessage());
                    }
                }
            }
        });
    }
    
    //PURPOSE:- Update the text
    private void logMessage(String message) 
    {
        Platform.runLater(() -> logArea.appendText(message + "\n"));
    }

    /*I decided to have method level synchronization because i added the functionality of Displaying Status on the status label after I finished the 
     * simulation. So I added multiple methods as possible instead of changing the code that already works because program loves errors and I didn't want anymore.
     * This made it easier to add that feature and it's very simple logic too compare to trying somthing else.
    */

    //PURPOSE:- Updating the planes in flight
    @SuppressWarnings("PMD.AvoidSynchronizedAtMethodLevel")
    public synchronized void incrementPlanesInFlight() 
    {
        planesInFlight++;
        updateStatusLabel();
    }

    //PURPOSE:- Updating the planes in flight
    @SuppressWarnings("PMD.AvoidSynchronizedAtMethodLevel")
    public synchronized void decrementPlanesInFlight() 
    {
        planesInFlight--;
        updateStatusLabel();
    }

    //PURPOSE:- Updating the planes in service
    @SuppressWarnings("PMD.AvoidSynchronizedAtMethodLevel")
    public synchronized void incrementPlanesInService() 
    {
        planesInService++;
        updateStatusLabel();
    }

    //PURPOSE:- Updating the planes in service
    @SuppressWarnings("PMD.AvoidSynchronizedAtMethodLevel")
    public synchronized void decrementPlanesInService() 
    {
        planesInService--;
        updateStatusLabel();
    }

    //PURPOSE:- Updating the completed trips
    @SuppressWarnings("PMD.AvoidSynchronizedAtMethodLevel")
    public synchronized void incrementCompletedTrips() 
    {
        completedTrips++;
        updateStatusLabel();
    }


    //PURPOSE:- Updating the status label
    private void updateStatusLabel() 
    {
        Platform.runLater(() -> 
        {
            String status = String.format("In-flight: %d | In service: %d | Completed trips: %d", 
                                          planesInFlight, planesInService, completedTrips);
            
            App.setStatusText(status);
        });
    }

    //PURPOSE:- Setting the plane service manager
    public void setPlaneServiceManager(PlaneServiceManager planeServiceManager) 
    {
        this.planeServiceManager = planeServiceManager;
    }





    
}


